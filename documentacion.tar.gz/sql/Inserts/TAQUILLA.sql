INSERT INTO TAQUILLA VALUES(SQ_TAQU_codigo.nextval,'apuesta');
INSERT INTO TAQUILLA VALUES(SQ_TAQU_codigo.nextval,'boleto');
INSERT INTO TAQUILLA VALUES(SQ_TAQU_codigo.nextval,'apuesta');
INSERT INTO TAQUILLA VALUES(SQ_TAQU_codigo.nextval,'boleto');
INSERT INTO TAQUILLA VALUES(SQ_TAQU_codigo.nextval,'apuesta');
INSERT INTO TAQUILLA VALUES(SQ_TAQU_codigo.nextval,'boleto');
INSERT INTO TAQUILLA VALUES(SQ_TAQU_codigo.nextval,'apuesta');
INSERT INTO TAQUILLA VALUES(SQ_TAQU_codigo.nextval,'boleto');
