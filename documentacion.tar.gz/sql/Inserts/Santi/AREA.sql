INSERT INTO AREA VALUES (SQ_AREA_codigo.nextval,500,'Tribuna','Capacidad para 500 personas');
INSERT INTO AREA VALUES (SQ_AREA_codigo.nextval,50,'Palco','Capacidad para 50 personas');
INSERT INTO AREA VALUES (SQ_AREA_codigo.nextval,1700,'Gradas.','Capacidad para 1700 personas');
INSERT INTO AREA VALUES (SQ_AREA_codigo.nextval,800,'Mezzanina','Capacidad para 800 personas');
INSERT INTO AREA VALUES (SQ_AREA_codigo.nextval,800,'Circulo de ganadores','Capacidad para 800 personas');
INSERT INTO AREA VALUES (SQ_AREA_codigo.nextval,800,'Playa','Capacidad para 800 personas');
INSERT INTO AREA VALUES (SQ_AREA_codigo.nextval,800,'Butaca','Capacidad para 800 personas');

