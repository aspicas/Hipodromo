INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'14:00:00','15:00:00','viernes');
INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'14:00:00','15:00:00','sabado');
INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'14:00:00','15:00:00','domingo');

INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'12:30:00','13:00:00','viernes');
INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'12:30:00','13:00:00','sabado');
INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'12:30:00','13:00:00','domingo');

INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'13:00:00','13:00:00','viernes');
INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'13:00:00','01:30:00','sabado');
INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'13:00:00','01:30:00','domingo');

INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'13:30:00','14:00:00','viernes');
INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'13:30:00','14:00:00','sabado');
INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'13:30:00','14:00:00','domingo');

INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'14:00:00','14:30:00','viernes');
INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'14:00:00','14:30:00','sabado');
INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'14:00:00','14:30:00','domingo');

INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'14:30:00','15:00:00','viernes');
INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'14:30:00','15:00:00','sabado');
INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'14:30:00','15:00:00','domingo');

INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'15:00:00','15:30:00','viernes');
INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'15:00:00','15:30:00','sabado');
INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'15:00:00','15:30:00','domingo');

INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'15:30:00','16:00:00','viernes');
INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'15:30:00','16:00:00','sabado');
INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'15:30:00','16:00:00','domingo');

INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'16:00:00','16:30:00','viernes');
INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'16:00:00','16:30:00','sabado');
INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'16:00:00','16:30:00','domingo');

INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'16:30:00','01:00:00','viernes');
INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'16:30:00','17:00:00','sabado');
INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'16:30:00','17:00:00','domingo');

INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'17:00:00','17:30:00','viernes');
INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'17:00:00','17:30:00','sabado');
INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'17:00:00','17:30:00','domingo');

INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'17:30:00','18:00:00','viernes');
INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'17:30:00','18:00:00','sabado');
INSERT INTO HORA VALUES (SQ_HORA_codigo.nextval,'17:30:00','18:00:00','domingo');