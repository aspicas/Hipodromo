INSERT INTO COLOR VALUES (SQ_COLO_codigo.nextval,'Azul');
INSERT INTO COLOR VALUES (SQ_COLO_codigo.nextval,'Rojo');
INSERT INTO COLOR VALUES (SQ_COLO_codigo.nextval,'Morado');
INSERT INTO COLOR VALUES (SQ_COLO_codigo.nextval,'Naranja');
INSERT INTO COLOR VALUES (SQ_COLO_codigo.nextval,'Rosado');
INSERT INTO COLOR VALUES (SQ_COLO_codigo.nextval,'Negro');
INSERT INTO COLOR VALUES (SQ_COLO_codigo.nextval,'Blanco');
INSERT INTO COLOR VALUES (SQ_COLO_codigo.nextval,'Amarillo');
INSERT INTO COLOR VALUES (SQ_COLO_codigo.nextval,'Gris');
INSERT INTO COLOR VALUES (SQ_COLO_codigo.nextval,'Verde');


