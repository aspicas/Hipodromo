INSERT INTO VETERINARIO  VALUES(SQ_VETE_codigo.nextval,'Ana','Rivas');
INSERT INTO VETERINARIO  VALUES(SQ_VETE_codigo.nextval,'Carolina','Oliveira');
INSERT INTO VETERINARIO  VALUES(SQ_VETE_codigo.nextval,'Daniela','Belfort');
INSERT INTO VETERINARIO  VALUES(SQ_VETE_codigo.nextval,'Alexandra','Contreras');
INSERT INTO VETERINARIO  VALUES(SQ_VETE_codigo.nextval,'Jesus','Atay');
INSERT INTO VETERINARIO VALUES(SQ_VETE_codigo.nextval,'Alejandro','Rodriguez');
INSERT INTO VETERINARIO  VALUES(SQ_VETE_codigo.nextval,'Gabriela','Murrillo');
INSERT INTO VETERINARIO  VALUES(SQ_VETE_codigo.nextval,'Samuel','Gonzalez');
INSERT INTO VETERINARIO  VALUES(SQ_VETE_codigo.nextval,'Miguel','Mendoza');
INSERT INTO VETERINARIO  VALUES(SQ_VETE_codigo.nextval,'Ana','Miranda');
INSERT INTO VETERINARIO  VALUES(SQ_VETE_codigo.nextval,'Thais','Bonilla');

