INSERT INTO ENFERMEDAD VALUES(SQ_ENFE_codigo.nextval,'Cañeras','Es una lesíon en la membrana que cubre el hueso de los metacarpos ');
INSERT INTO ENFERMEDAD VALUES(SQ_ENFE_codigo.nextval,'Esparavanes','Es una dolencia que se localiza en los miembros posteriores');
INSERT INTO ENFERMEDAD VALUES(SQ_ENFE_codigo.nextval,'Carpitis','Se produe en una importante articulacion que representa en el humano la muñeca');
INSERT INTO ENFERMEDAD VALUES(SQ_ENFE_codigo.nextval,'Tendonitis','Se presenta con inflamacion en los tendones');
INSERT INTO ENFERMEDAD VALUES(SQ_ENFE_codigo.nextval,'Castracion','No resulta de mucho Problema');
INSERT INTO ENFERMEDAD VALUES(SQ_ENFE_codigo.nextval,'Miositis','Es una inflamacion en las paletas que produce intenso dolor');
INSERT INTO ENFERMEDAD VALUES(SQ_ENFE_codigo.nextval,'Erlichosis','Es una sobre carga téorica de parásitos especificos');
