INSERT INTO ENTRENADOR VALUES(SQ_ENTR_codigo.nextval,'Lenin','Cruz');
INSERT INTO ENTRENADOR VALUES(SQ_ENTR_codigo.nextval,'Ramón','García M');
INSERT INTO ENTRENADOR VALUES(SQ_ENTR_codigo.nextval,'Gilberto','Atencio');
INSERT INTO ENTRENADOR VALUES(SQ_ENTR_codigo.nextval,'Morris','Salswach');
INSERT INTO ENTRENADOR VALUES(SQ_ENTR_codigo.nextval,'Ernesto','Ochoa');
INSERT INTO ENTRENADOR VALUES(SQ_ENTR_codigo.nextval,'Fernando','Parilli');
INSERT INTO ENTRENADOR VALUES(SQ_ENTR_codigo.nextval,'Asdrúbal J','Medina');
INSERT INTO ENTRENADOR VALUES(SQ_ENTR_codigo.nextval,'Fernando','Parilli T');
INSERT INTO ENTRENADOR VALUES(SQ_ENTR_codigo.nextval,'José G','Querales');
INSERT INTO ENTRENADOR VALUES(SQ_ENTR_codigo.nextval,'Miguel','Contini');
INSERT INTO ENTRENADOR VALUES(SQ_ENTR_codigo.nextval,'Rubén','Lanz');
INSERT INTO ENTRENADOR VALUES(SQ_ENTR_codigo.nextval,'Alexis','Delgado');
INSERT INTO ENTRENADOR VALUES(SQ_ENTR_codigo.nextval,'Jose F','D Ángelo');
INSERT INTO ENTRENADOR VALUES(SQ_ENTR_codigo.nextval,'Cesar','Perez');
INSERT INTO ENTRENADOR VALUES(SQ_ENTR_codigo.nextval,'Humberto','Correia');

