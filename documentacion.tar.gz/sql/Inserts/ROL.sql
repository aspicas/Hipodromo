INSERT INTO ROL VALUES(SQ_ROL_codigo.nextval,'Jinete','LE');
INSERT INTO ROL VALUES(SQ_ROL_codigo.nextval,'Propietario','BLEM');
INSERT INTO ROL VALUES(SQ_ROL_codigo.nextval,'Invitado','LE');
INSERT INTO ROL VALUES(SQ_ROL_codigo.nextval,'Entrenador','BLM');
INSERT INTO ROL VALUES(SQ_ROL_codigo.nextval,'Veterinario','LE');
