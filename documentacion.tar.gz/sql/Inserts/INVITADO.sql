INSERT INTO INVITADO VALUES(SQ_INVI_codigo.nextval,'Nacho','Nacho','artista');
INSERT INTO INVITADO VALUES(SQ_INVI_codigo.nextval,'Carlos','Rodriguez','opinion');
INSERT INTO INVITADO VALUES(SQ_INVI_codigo.nextval,'Salomon','Rondon','deportista');
INSERT INTO INVITADO VALUES(SQ_INVI_codigo.nextval,'SixtoRein','Rein','artista');
INSERT INTO INVITADO VALUES(SQ_INVI_codigo.nextval,'Daniel','Pestana','opinion');