INSERT INTO UNIFORME VALUES(SQ_UNIF_codigo.nextval,'Camisa');
INSERT INTO UNIFORME VALUES(SQ_UNIF_codigo.nextval,'Gorra'),
INSERT INTO UNIFORME VALUES(SQ_UNIF_codigo.nextval,'Camisa');
INSERT INTO UNIFORME VALUES(SQ_UNIF_codigo.nextval,'Gorra');
INSERT INTO UNIFORME VALUES(SQ_UNIF_codigo.nextval,'Gorra');


