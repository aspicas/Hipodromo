INSERT INTO HARAS	VALUES(SQ_HARA_codigo.nextval,	'Mamoncito'	,(select LUGA_codigo from LUGAR where LUGA_tipo='CHACAO'));
INSERT INTO HARAS	VALUES(SQ_HARA_codigo.nextval,	'San Pablo'	,(select LUGA_codigo from LUGAR where LUGA_tipo='CHACAO'));
INSERT INTO HARAS	VALUES(SQ_HARA_codigo.nextval,	'La Quinta'	,(select LUGA_codigo from LUGAR where LUGA_tipo='CHACAO'));
INSERT INTO HARAS	VALUES(SQ_HARA_codigo.nextval,	'Estados Unidos'	,(select LUGA_codigo from LUGAR where LUGA_tipo='CHACAO'));
INSERT INTO HARAS	VALUES(SQ_HARA_codigo.nextval,	'San Gregorio'	,(select LUGA_codigo from LUGAR where LUGA_tipo='CHACAO'));
INSERT INTO HARAS	VALUES(SQ_HARA_codigo.nextval,	'La Montaña'	,(select LUGA_codigo from LUGAR where LUGA_tipo='CHACAO'));
INSERT INTO HARAS	VALUES(SQ_HARA_codigo.nextval,	'Urama'	,(select LUGA_codigo from LUGAR where LUGA_tipo='CHACAO'));
