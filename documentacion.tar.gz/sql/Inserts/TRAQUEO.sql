INSERT INTO TRAQUEO VALUES (SQ_TAAP_codigo.nextval,'true',TO_DATE('2015-12-15','yyyy-mm-dd'));
INSERT INTO TRAQUEO VALUES (SQ_TAAP_codigo.nextval,'false',TO_DATE('2015-12-15','yyyy-mm-dd'));
INSERT INTO TRAQUEO VALUES (SQ_TAAP_codigo.nextval,'true',TO_DATE('2015-12-15','yyyy-mm-dd'));
INSERT INTO TRAQUEO VALUES (SQ_TAAP_codigo.nextval,'false',TO_DATE('2015-12-17','yyyy-mm-dd'));
INSERT INTO TRAQUEO VALUES (SQ_TAAP_codigo.nextval,'false',TO_DATE('2015-12-11','yyyy-mm-dd'));
INSERT INTO TRAQUEO VALUES (SQ_TAAP_codigo.nextval,'false',TO_DATE('2015-12-14','yyyy-mm-dd'));
INSERT INTO TRAQUEO VALUES (SQ_TAAP_codigo.nextval,'true',TO_DATE('2015-12-13','yyyy-mm-dd'));
INSERT INTO TRAQUEO VALUES (SQ_TAAP_codigo.nextval,'false',TO_DATE(' 2015-12-12','yyyy-mm-dd'));
INSERT INTO TRAQUEO VALUES (SQ_TAAP_codigo.nextval,'false',TO_DATE('2015-12-10','yyyy-mm-dd'));
