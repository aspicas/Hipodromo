//INSERTS DE RESTAURANTE
INSERT INTO RESTAURANTE VALUES (SQ_REST_codigo.nextval,'Alamo');
INSERT INTO RESTAURANTE VALUES (SQ_REST_codigo.nextval,'Wendys');
INSERT INTO RESTAURANTE VALUES (SQ_REST_codigo.nextval,'Juanchis Burger');
INSERT INTO RESTAURANTE VALUES (SQ_REST_codigo.nextval,'McDonals');
INSERT INTO RESTAURANTE VALUES (SQ_REST_codigo.nextval,'Burger King');
INSERT INTO RESTAURANTE VALUES (SQ_REST_codigo.nextval,'Mama Nostra');
INSERT INTO RESTAURANTE VALUES (SQ_REST_codigo.nextval,'Shawarma Mix');
INSERT INTO RESTAURANTE VALUES (SQ_REST_codigo.nextval,'Budare');
INSERT INTO RESTAURANTE VALUES (SQ_REST_codigo.nextval,'Toque Zuliano');
INSERT INTO RESTAURANTE VALUES (SQ_REST_codigo.nextval,'Fridays');
INSERT INTO RESTAURANTE VALUES (SQ_REST_codigo.nextval,'Avila Burger');
INSERT INTO RESTAURANTE VALUES (SQ_REST_codigo.nextval,'Migas');
INSERT INTO RESTAURANTE VALUES (SQ_REST_codigo.nextval,'Heladeria 4D');
INSERT INTO RESTAURANTE VALUES (SQ_REST_codigo.nextval,'Hong Fung');
INSERT INTO RESTAURANTE VALUES (SQ_REST_codigo.nextval,'Salon Canton');
INSERT INTO RESTAURANTE VALUES (SQ_REST_codigo.nextval,'Arturos');
INSERT INTO RESTAURANTE VALUES (SQ_REST_codigo.nextval,'Danubio');
INSERT INTO RESTAURANTE VALUES (SQ_REST_codigo.nextval,'Alazan');
INSERT INTO RESTAURANTE VALUES (SQ_REST_codigo.nextval,'La Estancia');
INSERT INTO RESTAURANTE VALUES (SQ_REST_codigo.nextval,'Cookies');
INSERT INTO RESTAURANTE VALUES (SQ_REST_codigo.nextval,'Buono');

//INSERTS DE AREA
INSERT INTO AREA VALUES (SQ_AREA_codigo.nextval,300,'paddock','Capacidad para 300 personas');
INSERT INTO AREA VALUES (SQ_AREA_codigo.nextval,300,'circulo de ganadores','Capacidad para 300 personas');
INSERT INTO AREA VALUES (SQ_AREA_codigo.nextval,300,'grada central','Capacidad para 300 personas');
INSERT INTO AREA VALUES (SQ_AREA_codigo.nextval,300,'tribuna','Capacidad para 300 personas');
INSERT INTO AREA VALUES (SQ_AREA_codigo.nextval,300,'estacionamiento','Capacidad para 300 personas');
INSERT INTO AREA VALUES (SQ_AREA_codigo.nextval,300,'butaca','Capacidad para 300 personas');
INSERT INTO AREA VALUES (SQ_AREA_codigo.nextval,300,'playa','Capacidad para 300 personas');
INSERT INTO AREA VALUES (SQ_AREA_codigo.nextval,300,'pasillo','Capacidad para 300 personas');
INSERT INTO AREA VALUES (SQ_AREA_codigo.nextval,300,'palco','Capacidad para 300 personas');

//INSERTS DE PISO
INSERT INTO PISO VALUES (SQ_PISO_codigo.nextval,'nivel 1',(select area_codigo from area where area_tipo='butaca'));
INSERT INTO PISO VALUES (SQ_PISO_codigo.nextval,'nivel 1',(select area_codigo from area where area_tipo='butaca'));
INSERT INTO PISO VALUES (SQ_PISO_codigo.nextval,'nivel 1',(select area_codigo from area where area_tipo='butaca'));
INSERT INTO PISO VALUES (SQ_PISO_codigo.nextval,'nivel 1',(select area_codigo from area where area_tipo='butaca'));
INSERT INTO PISO VALUES (SQ_PISO_codigo.nextval,'nivel 1',(select area_codigo from area where area_tipo='butaca'));
INSERT INTO PISO VALUES (SQ_PISO_codigo.nextval,'nivel 1',(select area_codigo from area where area_tipo='butaca'));
INSERT INTO PISO VALUES (SQ_PISO_codigo.nextval,'nivel 1',(select area_codigo from area where area_tipo='butaca'));
INSERT INTO PISO VALUES (SQ_PISO_codigo.nextval,'nivel 1',(select area_codigo from area where area_tipo='butaca'));
INSERT INTO PISO VALUES (SQ_PISO_codigo.nextval,'nivel 1',(select area_codigo from area where area_tipo='butaca'));
INSERT INTO PISO VALUES (SQ_PISO_codigo.nextval,'nivel 1',(select area_codigo from area where area_tipo='butaca'));
INSERT INTO PISO VALUES (SQ_PISO_codigo.nextval,'nivel 1',(select area_codigo from area where area_tipo='butaca'));
INSERT INTO PISO VALUES (SQ_PISO_codigo.nextval,'nivel 1',(select area_codigo from area where area_tipo='butaca'));
INSERT INTO PISO VALUES (SQ_PISO_codigo.nextval,'nivel 1',(select area_codigo from area where area_tipo='butaca'));
INSERT INTO PISO VALUES (SQ_PISO_codigo.nextval,'nivel 1',(select area_codigo from area where area_tipo='butaca'));
INSERT INTO PISO VALUES (SQ_PISO_codigo.nextval,'nivel 1',(select area_codigo from area where area_tipo='butaca'));
INSERT INTO PISO VALUES (SQ_PISO_codigo.nextval,'nivel 1',(select area_codigo from area where area_tipo='butaca'));
INSERT INTO PISO VALUES (SQ_PISO_codigo.nextval,'nivel 1',(select area_codigo from area where area_tipo='butaca'));
INSERT INTO PISO VALUES (SQ_PISO_codigo.nextval,'nivel 1',(select area_codigo from area where area_tipo='butaca'));
INSERT INTO PISO VALUES (SQ_PISO_codigo.nextval,'nivel 1',(select area_codigo from area where area_tipo='butaca'));
INSERT INTO PISO VALUES (SQ_PISO_codigo.nextval,'nivel 1',(select area_codigo from area where area_tipo='butaca'));

//INSERTS DE RESA
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='paddock'),(select REST_codigo from RESTAURANTE where REST_nombre='Alamo'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='paddock'),(select REST_codigo from RESTAURANTE where REST_nombre='Wendys'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='paddock'),(select REST_codigo from RESTAURANTE where REST_nombre='Juanchis Burger'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='paddock'),(select REST_codigo from RESTAURANTE where REST_nombre='McDonals'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='circulo de ganadores'),(select REST_codigo from RESTAURANTE where REST_nombre='Burger King'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='circulo de ganadores'),(select REST_codigo from RESTAURANTE where REST_nombre='Mama Nostra'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='circulo de ganadores'),(select REST_codigo from RESTAURANTE where REST_nombre='Shawarma Mix'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='circulo de ganadores'),(select REST_codigo from RESTAURANTE where REST_nombre='Budare'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='grada central'),(select REST_codigo from RESTAURANTE where REST_nombre='Toque Zuliano'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='grada central'),(select REST_codigo from RESTAURANTE where REST_nombre='Fridays'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='grada central'),(select REST_codigo from RESTAURANTE where REST_nombre='Avila Burger'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='grada central'),(select REST_codigo from RESTAURANTE where REST_nombre='Migas'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='tribuna'),(select REST_codigo from RESTAURANTE where REST_nombre='Heladeria 4D'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='tribuna'),(select REST_codigo from RESTAURANTE where REST_nombre='Hong Fung'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='tribuna'),(select REST_codigo from RESTAURANTE where REST_nombre='Salon Canton'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='tribuna'),(select REST_codigo from RESTAURANTE where REST_nombre='Arturos'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='butaca'),(select REST_codigo from RESTAURANTE where REST_nombre='Danubio'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='butaca'),(select REST_codigo from RESTAURANTE where REST_nombre='Alazan'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='butaca'),(select REST_codigo from RESTAURANTE where REST_nombre='La Estancia'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='butaca'),(select REST_codigo from RESTAURANTE where REST_nombre='Cookies'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='playa'),(select REST_codigo from RESTAURANTE where REST_nombre='Alamo'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='playa'),(select REST_codigo from RESTAURANTE where REST_nombre='Wendys'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='playa'),(select REST_codigo from RESTAURANTE where REST_nombre='Juanchis Burger'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='playa'),(select REST_codigo from RESTAURANTE where REST_nombre='Buono'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='pasillo'),(select REST_codigo from RESTAURANTE where REST_nombre='McDonals'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='pasillo'),(select REST_codigo from RESTAURANTE where REST_nombre='Burger King'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='pasillo'),(select REST_codigo from RESTAURANTE where REST_nombre='Mama Nostra'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='pasillo'),(select REST_codigo from RESTAURANTE where REST_nombre='Shawarma Mix'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='palco'),(select REST_codigo from RESTAURANTE where REST_nombre='Budare'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='palco'),(select REST_codigo from RESTAURANTE where REST_nombre='Toque Zuliano'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='palco'),(select REST_codigo from RESTAURANTE where REST_nombre='Fridays'));
INSERT INTO RESA VALUES (SQ_RESA_codigo.nextval,(select AREA_codigo from AREA where AREA_nombre='palco'),(select REST_codigo from RESTAURANTE where REST_nombre='Avila Burger'));

//INSERTS DE COLOR
INSERT INTO COLOR VALUES (SQ_COLO_codigo.nextval,'Azul');
INSERT INTO COLOR VALUES (SQ_COLO_codigo.nextval,'Rojo');
INSERT INTO COLOR VALUES (SQ_COLO_codigo.nextval,'Morado');
INSERT INTO COLOR VALUES (SQ_COLO_codigo.nextval,'Naranja');
INSERT INTO COLOR VALUES (SQ_COLO_codigo.nextval,'Rosado');
INSERT INTO COLOR VALUES (SQ_COLO_codigo.nextval,'Negro');
INSERT INTO COLOR VALUES (SQ_COLO_codigo.nextval,'Blanco');
INSERT INTO COLOR VALUES (SQ_COLO_codigo.nextval,'Amarillo');
INSERT INTO COLOR VALUES (SQ_COLO_codigo.nextval,'Marron');
INSERT INTO COLOR VALUES (SQ_COLO_codigo.nextval,'Verde');
INSERT INTO COLOR VALUES (SQ_COLO_codigo.nextval,'Turquesa');
INSERT INTO COLOR VALUES (SQ_COLO_codigo.nextval,'Vinotinto');
INSERT INTO COLOR VALUES (SQ_COLO_codigo.nextval,'Lila');
INSERT INTO COLOR VALUES (SQ_COLO_codigo.nextval,'Gris');

//INSERTS DE PISTA
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1265,709);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,468,763);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,641,854);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,720,347);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1207,816);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,426,913);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,813,401);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1957,575);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,874,523);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1295,326);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1692,741);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1757,821);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1113,644);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1185,959);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,473,511);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1735,666);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1413,773);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,770,700);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,887,973);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1045,544);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1814,834);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1416,601);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1445,283);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1402,742);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,471,890);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1393,701);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1632,473);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,404,226);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,948,357);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1584,908);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1803,611);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1961,213);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,957,590);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,650,698);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1512,337);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1811,993);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1500,349);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1845,781);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,645,679);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1887,908);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1804,639);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,489,272);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,712,512);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1390,837);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1476,710);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1333,860);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1859,695);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1802,736);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1700,576);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1354,383);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,701,587);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,882,250);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,687,429);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1151,493);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1498,746);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,710,655);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,942,869);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,505,629);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1665,645);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1154,798);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1929,273);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1204,288);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1866,782);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1323,891);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,758,417);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1478,345);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1727,665);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1038,833);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1306,253);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,894,275);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,914,492);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,587,932);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1990,583);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1749,846);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1941,733);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,732,855);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1581,736);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,866,258);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1564,685);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1325,984);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,912,567);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,910,295);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1962,984);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,961,306);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1798,818);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,553,607);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1142,855);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,883,212);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1755,398);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1608,733);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1361,973);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1432,573);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,768,285);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1580,268);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1372,330);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,1994,768);
INSERT INTO PISTA VALUES (SQ_PIST_codigo.nextval,745,748);

//INSERTS DE MATERIAL
INSERT INTO MATERIAL VALUES (SQ_MATE_codigo.nextval,'Arena',(select PIST_codigo from PISTA where PIST_longitud = 1800));
INSERT INTO MATERIAL VALUES (SQ_MATE_codigo.nextval,'Arena',(select PIST_codigo from PISTA where PIST_longitud = 1600));
INSERT INTO MATERIAL VALUES (SQ_MATE_codigo.nextval,'Arena',(select PIST_codigo from PISTA where PIST_longitud = 1500));
INSERT INTO MATERIAL VALUES (SQ_MATE_codigo.nextval,'Arena',(select PIST_codigo from PISTA where PIST_longitud = 1400));
INSERT INTO MATERIAL VALUES (SQ_MATE_codigo.nextval,'Arena',(select PIST_codigo from PISTA where PIST_longitud = 1300));
INSERT INTO MATERIAL VALUES (SQ_MATE_codigo.nextval,'Cesped',(select PIST_codigo from PISTA where PIST_longitud = 1200));
INSERT INTO MATERIAL VALUES (SQ_MATE_codigo.nextval,'Arena',(select PIST_codigo from PISTA where PIST_longitud = 1100));
INSERT INTO MATERIAL VALUES (SQ_MATE_codigo.nextval,'Cesped',(select PIST_codigo from PISTA where PIST_longitud = 1000));
INSERT INTO MATERIAL VALUES (SQ_MATE_codigo.nextval,'Arena',(select PIST_codigo from PISTA where PIST_longitud = 900));
INSERT INTO MATERIAL VALUES (SQ_MATE_codigo.nextval,'Cesped',(select PIST_codigo from PISTA where PIST_longitud = 800));
INSERT INTO MATERIAL VALUES (SQ_MATE_codigo.nextval,'Arena',(select PIST_codigo from PISTA where PIST_longitud = 700));
INSERT INTO MATERIAL VALUES (SQ_MATE_codigo.nextval,'Cesped',(select PIST_codigo from PISTA where PIST_longitud = 600));
INSERT INTO MATERIAL VALUES (SQ_MATE_codigo.nextval,'Arena',(select PIST_codigo from PISTA where PIST_longitud = 500));

//INSERS DE STUD
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Nero','11/11/1996');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Peter','10/03/1999');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Uriel','22/01/1994');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Timothy','25/11/2003');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Brett','04/05/2000');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Tyrone','23/06/2000');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Brendan','15/12/1997');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Elliott','14/11/1994');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Jameson','24/12/1997');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Marshall','13/01/2002');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Clark','23/08/2007');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Cedric','24/01/1993');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Cain','04/01/1999');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Nathan','17/10/2005');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Kuame','07/06/2007');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Tobias','12/04/2013');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Uriah','08/12/2001');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Allistair','13/01/1999');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Garrett','07/08/2009');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Isaiah','25/07/2015');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Nash','27/08/1995');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Duncan','08/12/1995');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Orson','30/08/2002');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Brody','19/04/1999');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Leroy','02/05/1993');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Prescott','19/05/1993');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Rogan','12/03/1998');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Ulric','16/03/2000');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Ulysses','04/01/2009');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Tiger','23/04/2002');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Upton','01/10/1994');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Drew','01/07/2008');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Christian','27/06/2010');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Harrison','03/09/1999');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Prescott','19/08/2013');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Craig','25/01/1993');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Axel','02/07/2001');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Griffith','04/10/2000');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Dane','04/07/1998');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Ulysses','22/03/2012');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Hamilton','31/12/1998');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Prescott','05/02/2011');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Finn','28/03/1996');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Solomon','16/05/1998');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Mark','05/08/1993');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Daquan','08/11/2001');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Fritz','03/02/2005');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Joshua','08/05/2011');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Timothy','29/08/2004');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Holmes','19/09/2000');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Joshua','09/09/1998');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Tad','18/11/2003');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Baxter','10/03/2007');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Jerry','28/11/1997');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Chase','08/06/2001');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Edward','29/06/2011');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Carson','19/12/2002');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Daquan','10/01/2002');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Theodore','09/04/2010');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Abbot','15/12/2013');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Clayton','27/08/1994');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Arthur','09/10/1993');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Gareth','12/12/2007');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Lamar','30/11/1999');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Honorato','22/04/2013');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Macon','17/07/2010');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Berk','08/12/2006');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Edan','21/03/1992');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Clayton','25/11/2002');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Xanthus','16/10/2001');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Justin','12/12/1999');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Elton','07/03/2014');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Emery','06/08/2015');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Tiger','21/02/1994');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Wayne','11/02/2011');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Len','30/03/1997');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Vaughan','20/03/2014');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Gray','04/10/1998');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Rooney','29/05/2006');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Stone','19/08/2003');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Gregory','26/07/2011');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Hamilton','14/03/2008');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Phillip','31/10/2002');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Levi','31/03/2013');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Scott','05/03/1995');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Avram','15/05/2015');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Wing','21/09/1991');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Addison','08/04/2012');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Paul','01/11/2007');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Jacob','12/09/2000');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Dane','01/11/1996');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Fuller','11/10/2014');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Gannon','04/05/1997');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Dustin','31/12/2006');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Talon','09/12/1996');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Louis','10/09/1995');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Ethan','20/01/2008');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Noble','08/10/2003');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Drew','25/12/2003');
INSERT INTO STUD VALUES (SQ_STUD_codigo.nextval,'Reed','02/04/2015');

//INSERTS DE LUGAR
INSERT INTO LUGAR VALUES (SQ_LUGA_codigo.nextval,'Venezuela','pais',null);
INSERT INTO LUGAR VALUES (SQ_LUGA_codigo.nextval,'Colombia','pais',null);
INSERT INTO LUGAR VALUES (SQ_LUGA_codigo.nextval,'Peru','pais',null);
INSERT INTO LUGAR VALUES (SQ_LUGA_codigo.nextval,'Ecuador','pais',null);
INSERT INTO LUGAR VALUES (SQ_LUGA_codigo.nextval,'Panama','pais',null);
INSERT INTO LUGAR VALUES (SQ_LUGA_codigo.nextval,'Argentina','pais',null);

INSERT INTO LUGAR VALUES (SQ_LUGA_codigo.nextval,'Distrito Capital','estado',(select LUGA_codigo from LUGAR where LUGA_nombre='Venezuela'));
INSERT INTO LUGAR VALUES (SQ_LUGA_codigo.nextval,'Miranda','estado',(select LUGA_codigo from LUGAR where LUGA_nombre='Venezuela'));
INSERT INTO LUGAR VALUES (SQ_LUGA_codigo.nextval,'Anzoategui','estado',(select LUGA_codigo from LUGAR where LUGA_nombre='Venezuela'));
INSERT INTO LUGAR VALUES (SQ_LUGA_codigo.nextval,'Merida','estado',(select LUGA_codigo from LUGAR where LUGA_nombre='Venezuela'));
INSERT INTO LUGAR VALUES (SQ_LUGA_codigo.nextval,'Cojedes','estado',(select LUGA_codigo from LUGAR where LUGA_nombre='Venezuela'));
INSERT INTO LUGAR VALUES (SQ_LUGA_codigo.nextval,'Portuguesa','estado',(select LUGA_codigo from LUGAR where LUGA_nombre='Venezuela'));
INSERT INTO LUGAR VALUES (SQ_LUGA_codigo.nextval,'Monagas','estado',(select LUGA_codigo from LUGAR where LUGA_nombre='Venezuela'));
INSERT INTO LUGAR VALUES (SQ_LUGA_codigo.nextval,'Zulia','estado',(select LUGA_codigo from LUGAR where LUGA_nombre='Venezuela'));
INSERT INTO LUGAR VALUES (SQ_LUGA_codigo.nextval,'Lara','estado',(select LUGA_codigo from LUGAR where LUGA_nombre='Venezuela'));
INSERT INTO LUGAR VALUES (SQ_LUGA_codigo.nextval,'Vargas','estado',(select LUGA_codigo from LUGAR where LUGA_nombre='Venezuela'));
INSERT INTO LUGAR VALUES (SQ_LUGA_codigo.nextval,'Aragua','estado',(select LUGA_codigo from LUGAR where LUGA_nombre='Venezuela'));
INSERT INTO LUGAR VALUES (SQ_LUGA_codigo.nextval,'Carabobo','estado',(select LUGA_codigo from LUGAR where LUGA_nombre='Venezuela'));

INSERT INTO LUGAR VALUES (SQ_LUGA_codigo.nextval,'Libertador','municipio',(select LUGA_codigo from LUGAR where LUGA_nombre='Distrito Capital'));
INSERT INTO LUGAR VALUES (SQ_LUGA_codigo.nextval,'Baruta','municipio',(select LUGA_codigo from LUGAR where LUGA_nombre='Miranda'));


//INSERTS DE PROPIETARIO
INSERT INTO PROPIETARIO VALUES (SQ_PROP_codigo.nextval,'Caleb','Murphy',21424696,(TO_DATE('2003/01/28')),'ipsum.Suspendisse@duinectempus.com',(select LUGA_codigo from LUGAR where LUGA_tipo=''));
INSERT INTO PROPIETARIO VALUES (SQ_PROP_codigo.nextval,'Quentin','Lynch',14020474,(TO_DATE('2010/12/13')),'et.commodo.at@ametornare.edu',(select LUGA_codigo from LUGAR where LUGA_tipo=''));

//INSERTS DE TELEFONO

//INSERTS DE ENTRENADOR
INSERT INTO ENTRENADOR VALUES(SQ_ENTRENADOR_codigo.nextval'Lenín','Cruz');
INSERT INTO ENTRENADOR VALUES(SQ_ENTRENADOR_codigo.nextval,'Ramón','García M');
INSERT INTO ENTRENADOR VALUES(SQ_ENTRENADOR_codigo.nextval,'Gilberto','Atencio');
INSERT INTO ENTRENADOR VALUES(SQ_ENTRENADOR_codigo.nextval,'Morris','Salswach');
INSERT INTO ENTRENADOR VALUES(SQ_ENTRENADOR_codigo.nextval,'Ernesto','Ochoa');
INSERT INTO ENTRENADOR VALUES(SQ_ENTRENADOR_codigo.nextval,'Fernando','Parilli');
INSERT INTO ENTRENADOR VALUES(SQ_ENTRENADOR_codigo.nextval,'Asdrúbal J','Medina');
INSERT INTO ENTRENADOR VALUES(SQ_ENTRENADOR_codigo.nextval,'Fernando','Parilli T');
INSERT INTO ENTRENADOR VALUES(SQ_ENTRENADOR_codigo.nextval,'José G','Querales');
INSERT INTO ENTRENADOR VALUES(SQ_ENTRENADOR_codigo.nextval,'Miguel','Contini');
INSERT INTO ENTRENADOR VALUES(SQ_ENTRENADOR_codigo.nextval,'Rubén','Lanz');
INSERT INTO ENTRENADOR VALUES(SQ_ENTRENADOR_codigo.nextval,'Alexis','Delgado');
INSERT INTO ENTRENADOR VALUES(SQ_ENTRENADOR_codigo.nextval,'Jose F','D Ángelo');
INSERT INTO ENTRENADOR VALUES(SQ_ENTRENADOR_codigo.nextval,'Cesar','Perez');
INSERT INTO ENTRENADOR VALUES(SQ_ENTRENADOR_codigo.nextval,'Humberto','Correia');

//INSERTS DE VETERINARIO
INSERT INTO VETERINARIO  VALUES(SQ_VETE_codigo.nextval,'Ana','Rivas');
INSERT INTO VETERINARIO  VALUES(SQ_VETE_codigo.nextval,'Carolina','Oliveira');
INSERT INTO VETERINARIO  VALUES(SQ_VETE_codigo.nextval,'Daniela','Belfort');
INSERT INTO VETERINARIO  VALUES(SQ_VETE_codigo.nextval,'Alexandra','Contreras');
INSERT INTO VETERINARIO  VALUES(SQ_VETE_codigo.nextval,'Jesus','Atay');
INSERT INTO VETERINARIO VALUES(SQ_VETE_codigo.nextval,'Alejandro','Rodriguez');
INSERT INTO VETERINARIO  VALUES(SQ_VETE_codigo.nextval,'Gabriela','Murrillo');
INSERT INTO VETERINARIO  VALUES(SQ_VETE_codigo.nextval,'Samuel','Gonzalez');
INSERT INTO VETERINARIO  VALUES(SQ_VETE_codigo.nextval,'Miguel','Mendoza');
INSERT INTO VETERINARIO  VALUES(SQ_VETE_codigo.nextval,'Ana','Miranda');
INSERT INTO VETERINARIO  VALUES(SQ_VETE_codigo.nextval,'Thais','Bonilla');

//INSERTS DE JINETE
INSERT INTO JINETE VALUES(SQ_JINE_codigo.nextval,'Eduardo','Gutiérrez',(TO_DATE(1974/11/23)),12345695,1.48,'true');
INSERT INTO JINETE VALUES(SQ_JINE_codigo.nextval,'Carlos','Rojas',(TO_DATE(1985/11/12)),19293430,1.52,'true');

//INSERTS DE INVITADO
INSERT INTO INVITADO VALUES(SQ_INVI_codigo.nextval,'Nacho','Nacho','artista');
INSERT INTO INVITADO VALUES(SQ_INVI_codigo.nextval,'Carlos','Rodriguez','opinion');
INSERT INTO INVITADO VALUES(SQ_INVI_codigo.nextval,'Salomon','Rondon','deportista');
INSERT INTO INVITADO VALUES(SQ_INVI_codigo.nextval,'SixtoRein','Rein','artista');
INSERT INTO INVITADO VALUES(SQ_INVI_codigo.nextval,'Daniel','Pestana','opinion');

//INSERTS DE TAQUILLA
INSERT INTO TAQUILLA VALUES(SQ_TAQU_codigo.nextval,'apuesta');
INSERT INTO TAQUILLA VALUES(SQ_TAQU_codigo.nextval,'apuesta');
INSERT INTO TAQUILLA VALUES(SQ_TAQU_codigo.nextval,'apuesta');
INSERT INTO TAQUILLA VALUES(SQ_TAQU_codigo.nextval,'apuesta');
INSERT INTO TAQUILLA VALUES(SQ_TAQU_codigo.nextval,'apuesta');
INSERT INTO TAQUILLA VALUES(SQ_TAQU_codigo.nextval,'apuesta');
INSERT INTO TAQUILLA VALUES(SQ_TAQU_codigo.nextval,'apuesta');
INSERT INTO TAQUILLA VALUES(SQ_TAQU_codigo.nextval,'apuesta');
INSERT INTO TAQUILLA VALUES(SQ_TAQU_codigo.nextval,'apuesta');
INSERT INTO TAQUILLA VALUES(SQ_TAQU_codigo.nextval,'boleto');
INSERT INTO TAQUILLA VALUES(SQ_TAQU_codigo.nextval,'boleto');
INSERT INTO TAQUILLA VALUES(SQ_TAQU_codigo.nextval,'boleto');
INSERT INTO TAQUILLA VALUES(SQ_TAQU_codigo.nextval,'boleto');
INSERT INTO TAQUILLA VALUES(SQ_TAQU_codigo.nextval,'boleto');
INSERT INTO TAQUILLA VALUES(SQ_TAQU_codigo.nextval,'boleto');
INSERT INTO TAQUILLA VALUES(SQ_TAQU_codigo.nextval,'boleto');
INSERT INTO TAQUILLA VALUES(SQ_TAQU_codigo.nextval,'boleto');

//INSERTS DE IMPLEMENTO
INSERT INTO IMPLEMENTO  VALUES(SQ_IMPL_codigo.nextval,'Gríngolas',null);
INSERT INTO IMPLEMENTO  VALUES(SQ_IMPL_codigo.nextval,'Lengua Amarrada',null);
INSERT INTO IMPLEMENTO  VALUES(SQ_IMPL_codigo.nextval,'Bozal',null);
INSERT INTO IMPLEMENTO  VALUES(SQ_IMPL_codigo.nextval,'Bozal Lenguero',null);
INSERT INTO IMPLEMENTO  VALUES(SQ_IMPL_codigo.nextval,'Bozal Blanco',null);
INSERT INTO IMPLEMENTO  VALUES(SQ_IMPL_codigo.nextval,'Martingala Pretal',null);
INSERT INTO IMPLEMENTO  VALUES(SQ_IMPL_codigo.nextval,'Guayo',null);
INSERT INTO IMPLEMENTO  VALUES(SQ_IMPL_codigo.nextval,'Vendas',null);
INSERT INTO IMPLEMENTO  VALUES(SQ_IMPL_codigo.nextval,'Orejas Tapadas',null);
INSERT INTO IMPLEMENTO  VALUES(SQ_IMPL_codigo.nextval,'Látigo',null);
INSERT INTO IMPLEMENTO  VALUES(SQ_IMPL_codigo.nextval,'Herradura Aluminio','CC');
INSERT INTO IMPLEMENTO  VALUES(SQ_IMPL_codigo.nextval,'Herradura Aluminio','CH');

//INSERTS DE POSTE

//INSERTS DE MEDICAMENTO
INSERT INTO MEDICAMENTO VALUES(SQ_MEDI_codigo.nextval,'Buta');
INSERT INTO MEDICAMENTO VALUES(SQ_MEDI_codigo.nextval,'Lasix');
INSERT INTO MEDICAMENTO VALUES(SQ_MEDI_codigo.nextval,'Legend');
INSERT INTO MEDICAMENTO VALUES(SQ_MEDI_codigo.nextval,'Arterol');
INSERT INTO MEDICAMENTO VALUES(SQ_MEDI_codigo.nextval,'Artrocon');
INSERT INTO MEDICAMENTO VALUES(SQ_MEDI_codigo.nextval,'Salix');
INSERT INTO MEDICAMENTO VALUES(SQ_MEDI_codigo.nextval,'Uronort');

//INSERTS DE ENFERMEDAD
INSERT INTO ENFERMEDAD VALUES(SQ_ENFE_codigo.nextval,'Cañeras','Es una lesíon en la membrana que cubre el hueso de los metacarpos ');
INSERT INTO ENFERMEDAD VALUES(SQ_ENFE_codigo.nextval,'Esparavanes','Es una dolencia que se localiza en los miembros posteriores');
INSERT INTO ENFERMEDAD VALUES(SQ_ENFE_codigo.nextval,'Carpitis','Se produe en una importante articulacion que representa en el humano la muñeca');
INSERT INTO ENFERMEDAD VALUES(SQ_ENFE_codigo.nextval,'Tendonitis','Se presenta con inflamacion en los tendones ');
INSERT INTO ENFERMEDAD VALUES(SQ_ENFE_codigo.nextval,'Castracion','No resulta de mucho Problema');
INSERT INTO ENFERMEDAD VALUES(SQ_ENFE_codigo.nextval,'Miositis','Es una inflamacion en las paletas que produce intenso dolor ');
INSERT INTO ENFERMEDAD VALUES(SQ_ENFE_codigo.nextval,'Erlichosis','Es una sobre carga téorica de parásitos especificos ');

//INSERTS DE CABALLERIZA*
INSERT INTO CABALLERIZA VALUES(SQ_CABA_codigo.nextval,1 ,(select VETE_codigo from veterinario where VETE_nombre=''),(select ENTR_codigo from ENTRENADO where ENTR_nombre=''));
INSERT INTO CABALLERIZA VALUES(SQ_CABA_codigo.nextval,2 ,(select VETE_codigo from veterinario where VETE_nombre=''),(select ENTR_codigo from ENTRENADO where ENTR_nombre=''));
INSERT INTO CABALLERIZA VALUES(SQ_CABA_codigo.nextval,3 ,(select VETE_codigo from veterinario where VETE_nombre=''),(select ENTR_codigo from ENTRENADO where ENTR_nombre=''));
INSERT INTO CABALLERIZA VALUES(SQ_CABA_codigo.nextval,4 ,(select VETE_codigo from veterinario where VETE_nombre=''),(select ENTR_codigo from ENTRENADO where ENTR_nombre=''));
INSERT INTO CABALLERIZA VALUES(SQ_CABA_codigo.nextval,5 ,(select VETE_codigo from veterinario where VETE_nombre=''),(select ENTR_codigo from ENTRENADO where ENTR_nombre=''));
INSERT INTO CABALLERIZA VALUES(SQ_CABA_codigo.nextval,6 ,(select VETE_codigo from veterinario where VETE_nombre=''),(select ENTR_codigo from ENTRENADO where ENTR_nombre=''));
INSERT INTO CABALLERIZA VALUES(SQ_CABA_codigo.nextval,7 ,(select VETE_codigo from veterinario where VETE_nombre=''),(select ENTR_codigo from ENTRENADO where ENTR_nombre=''));
INSERT INTO CABALLERIZA VALUES(SQ_CABA_codigo.nextval,8 ,(select VETE_codigo from veterinario where VETE_nombre=''),(select ENTR_codigo from ENTRENADO where ENTR_nombre=''));
INSERT INTO CABALLERIZA VALUES(SQ_CABA_codigo.nextval,9 ,(select VETE_codigo from veterinario where VETE_nombre=''),(select ENTR_codigo from ENTRENADO where ENTR_nombre=''));
INSERT INTO CABALLERIZA VALUES(SQ_CABA_codigo.nextval,10,(select VETE_codigo from veterinario where VETE_nombre=''),(select ENTR_codigo from ENTRENADO where ENTR_nombre=''));
INSERT INTO CABALLERIZA VALUES(SQ_CABA_codigo.nextval,11,(select VETE_codigo from veterinario where VETE_nombre=''),(select ENTR_codigo from ENTRENADO where ENTR_nombre=''));
INSERT INTO CABALLERIZA VALUES(SQ_CABA_codigo.nextval,12,(select VETE_codigo from veterinario where VETE_nombre=''),(select ENTR_codigo from ENTRENADO where ENTR_nombre=''));
INSERT INTO CABALLERIZA VALUES(SQ_CABA_codigo.nextval,13,(select VETE_codigo from veterinario where VETE_nombre=''),(select ENTR_codigo from ENTRENADO where ENTR_nombre=''));
INSERT INTO CABALLERIZA VALUES(SQ_CABA_codigo.nextval,14,(select VETE_codigo from veterinario where VETE_nombre=''),(select ENTR_codigo from ENTRENADO where ENTR_nombre=''));
INSERT INTO CABALLERIZA VALUES(SQ_CABA_codigo.nextval,15,(select VETE_codigo from veterinario where VETE_nombre=''),(select ENTR_codigo from ENTRENADO where ENTR_nombre=''));
INSERT INTO CABALLERIZA VALUES(SQ_CABA_codigo.nextval,16,(select VETE_codigo from veterinario where VETE_nombre=''),(select ENTR_codigo from ENTRENADO where ENTR_nombre=''));
INSERT INTO CABALLERIZA VALUES(SQ_CABA_codigo.nextval,17,(select VETE_codigo from veterinario where VETE_nombre=''),(select ENTR_codigo from ENTRENADO where ENTR_nombre=''));
INSERT INTO CABALLERIZA VALUES(SQ_CABA_codigo.nextval,18,(select VETE_codigo from veterinario where VETE_nombre=''),(select ENTR_codigo from ENTRENADO where ENTR_nombre=''));
INSERT INTO CABALLERIZA VALUES(SQ_CABA_codigo.nextval,19,(select VETE_codigo from veterinario where VETE_nombre=''),(select ENTR_codigo from ENTRENADO where ENTR_nombre=''));
INSERT INTO CABALLERIZA VALUES(SQ_CABA_codigo.nextval,20,(select VETE_codigo from veterinario where VETE_nombre=''),(select ENTR_codigo from ENTRENADO where ENTR_nombre=''));
INSERT INTO CABALLERIZA VALUES(SQ_CABA_codigo.nextval,21,(select VETE_codigo from veterinario where VETE_nombre=''),(select ENTR_codigo from ENTRENADO where ENTR_nombre=''));
INSERT INTO CABALLERIZA VALUES(SQ_CABA_codigo.nextval,22,(select VETE_codigo from veterinario where VETE_nombre=''),(select ENTR_codigo from ENTRENADO where ENTR_nombre=''));

//INSERTS DE TRAQUEO

//INSERTS DE USUARIO*

//INSERTS DE ROL
INSERT INTO ROL VALUES(SQ_ROL_codigo.nextval,'Jinete','LE');
INSERT INTO ROL VALUES(SQ_ROL_codigo.nextval,'Propietario','BLEM');
INSERT INTO ROL VALUES(SQ_ROL_codigo.nextval,'Invitado','LE');
INSERT INTO ROL VALUES(SQ_ROL_codigo.nextval,'Entrenador','BLM');
INSERT INTO ROL VALUES(SQ_ROL_codigo.nextval,'Veterinario','LE');

//INSERTS DE APUESTA
INSERT INTO APUESTA VALUES(SQ_APUE_codigo.nextval,'El 5 y 6 ',null,'Vale par las seis ultimas carreras del viernes y domingo ');
INSERT INTO APUESTA VALUES(SQ_APUE_codigo.nextval,'5 y 6 Electrónico',null,'Es valido para las seis últimas carreras de cada programa,se escoge cualquier numero de caballos, se van multiplicando y luego me multiplica por 100');
INSERT INTO APUESTA VALUES(SQ_APUE_codigo.nextval,'Ganador',5,'5 mínimo por cada bs 100 jugados a cada caballo ');
INSERT INTO APUESTA VALUES(SQ_APUE_codigo.nextval,'Placé',5,'Se juega cuando hay mas de diez caballo en la carrera , paga el primero o el segundo ');
INSERT INTO APUESTA VALUES(SQ_APUE_codigo.nextval,'Trifecta Sencilla',200,'Se juegan tres caballos y se gana si llegas en el mismo orden en que se jugaron ');
INSERT INTO APUESTA VALUES(SQ_APUE_codigo.nextval,'Trifecta Combinada',1200,'Son tres Caballos en cualquier orden');
INSERT INTO APUESTA VALUES(SQ_APUE_codigo.nextval,'Superfecta Sencilla',200,'Son cuatro caballos en el orden estricto de llegada ');
INSERT INTO APUESTA VALUES(SQ_APUE_codigo.nextval,'Superfecta Combinada',2400,'Son cuatro caballos en cualquier orden de llegada ');
INSERT INTO APUESTA VALUES(SQ_APUE_codigo.nextval,'Loto Hípico',200,'Se juega en las diez ultimas carreras de cada reunion. Gana si llega del primero al tercero. se escoje un cabballo por carrera');
INSERT INTO APUESTA VALUES(SQ_APUE_codigo.nextval,'Exacta Sencilla',200,'Se gana con el primero y el segundo en el orden de llegada ');
INSERT INTO APUESTA VALUES(SQ_APUE_codigo.nextval,'Exacta Combinada',400,'Dos caballos que lleguen primero y segundo, no imrpota el orden ');
INSERT INTO APUESTA VALUES(SQ_APUE_codigo.nextval,'Doble Perfecta',200,'Las carreras las escoge el hipodromo,normalmente son dos carreras consecutivas.Gana si el caballos llega como se jugó');
INSERT INTO APUESTA VALUES(SQ_APUE_codigo.nextval,'Pool de Cuatro',200,'Cuatro carreras consecutivas ganando');

//INSERTS DE ROUS*
INSERT INTO ROUS   VALUES (SQ_ROUS_codigo.nextval,(select   USUA_codigo from USUARIO WHERE  USUA_nombre='') ,(select ROL_codigo from ROL WHERE ROL_nombre=''));
INSERT INTO ROUS   VALUES (SQ_ROUS_codigo.nextval,(select   USUA_codigo from USUARIO WHERE  USUA_nombre='') ,(select ROL_codigo from ROL WHERE ROL_nombre=''));
INSERT INTO ROUS   VALUES (SQ_ROUS_codigo.nextval,(select   USUA_codigo from USUARIO WHERE  USUA_nombre='') ,(select ROL_codigo from ROL WHERE ROL_nombre=''));
INSERT INTO ROUS   VALUES (SQ_ROUS_codigo.nextval,(select   USUA_codigo from USUARIO WHERE  USUA_nombre='') ,(select ROL_codigo from ROL WHERE ROL_nombre=''));
INSERT INTO ROUS   VALUES (SQ_ROUS_codigo.nextval,(select   USUA_codigo from USUARIO WHERE  USUA_nombre='') ,(select ROL_codigo from ROL WHERE ROL_nombre=''));

//INSERTS DE HARA
INSERT INTO HARAS	VALUES(SQ_HARA_codigo.nextval,	'Mamoncito'	,(select LUGA_codigo from LUGAR where LUGA_tipo='CHACAO'));
INSERT INTO HARAS	VALUES(SQ_HARA_codigo.nextval,	'San Pablo'	,(select LUGA_codigo from LUGAR where LUGA_tipo='CHACAO'));
INSERT INTO HARAS	VALUES(SQ_HARA_codigo.nextval,	'La Quinta'	,(select LUGA_codigo from LUGAR where LUGA_tipo='CHACAO'));
INSERT INTO HARAS	VALUES(SQ_HARA_codigo.nextval,	'Estados Unidos'	,(select LUGA_codigo from LUGAR where LUGA_tipo='CHACAO'));
INSERT INTO HARAS	VALUES(SQ_HARA_codigo.nextval,	'San Gregorio'	,(select LUGA_codigo from LUGAR where LUGA_tipo='CHACAO'));
INSERT INTO HARAS	VALUES(SQ_HARA_codigo.nextval,	'La Montaña'	,(select LUGA_codigo from LUGAR where LUGA_tipo='CHACAO'));
INSERT INTO HARAS	VALUES(SQ_HARA_codigo.nextval,	'Urama'	,(select LUGA_codigo from LUGAR where LUGA_tipo='CHACAO'));

//INSERTS DE UNIFORME
INSERT INTO UNIFORME VALUES(SQ_UNIF_codigo.nextval,'Camisa');
INSERT INTO UNIFORME VALUES(SQ_UNIF_codigo.nextval,'Gorra');
INSERT INTO UNIFORME VALUES(SQ_UNIF_codigo.nextval,'Pantalon');
INSERT INTO UNIFORME VALUES(SQ_UNIF_codigo.nextval,'Casco');
INSERT INTO UNIFORME VALUES(SQ_UNIF_codigo.nextval,'Botas');
INSERT INTO UNIFORME VALUES(SQ_UNIF_codigo.nextval,'Fusta');
INSERT INTO UNIFORME VALUES(SQ_UNIF_codigo.nextval,'Breech');
INSERT INTO UNIFORME VALUES(SQ_UNIF_codigo.nextval,'Blazer');

//INSERTS DE CABALLERIZA


//INSERTS DE PUESTO

//INSERTS DE EJEMPLAR
INSERT INTO EJEMPLAR VALUES (SQ_EJEM_codigo.nextval,'A Rod Parts','Castano','08/08/1982','Masculino','L5Y 2K7','Raza',(select EJEM_codigo from EJEMPLAR where EJEM_nombre='' and EJEM_fecha_nac=''),(select EJEM_codigo from EJEMPLAR where EJEM_nombre='' and EJEM_fecha_nac=''),(select HARA_codigo from HARAS where HARA_nombre=''),(select PUES_codigo from PUESTO where PUES_numero=  and FK_CABA = ));

//INSERTS DE HORA

//INSERTS CARRERA*

//INSERTS DE PREMIO*

//INSERTS DE CAEJ

//INSERTS DE PESO*

//INSERTS DE IMCA

//INTERS DE POCA

//INSERTS DE EJTR

//INSERTS DE CAME

//INSERTS DE ENCA

//INSERTS DE ENVE

//INSERTS DE COMENTARIO

//INSERTS DE ARTA

//INSERTS DE TAAP

//INSERTS DE CAAP

//INSERTS DE HORE

//INSERTS DE PEAR

//INSERTS DE COST

//INSERTS DE PRST
